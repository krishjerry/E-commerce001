import React from 'react'
import { useSelector } from 'react-redux/es/exports'

const Card = () => {
  return (
    <div>
      The End
    </div>
  )
}

export default Card