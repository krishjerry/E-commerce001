import React from 'react'
import {carousel} from 'react-bootstrap'

const About = () => {
  return (
<div>  

</div>

  )
}

export default About;