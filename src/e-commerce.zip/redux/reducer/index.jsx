import handleCart from "./handleCart";
// import {combineReducers} from "react-redux";
import { combineReducers } from 'redux'

const rootReducer = combineReducers({
    handleCart,
})

export default rootReducer;